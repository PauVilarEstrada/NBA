import { useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import { PageTransition, riseItem, stagger } from '@/components/ui/PageTransition'
import { GlassCard } from '@/components/ui/GlassCard'
import { SectionTitle, Segmented } from '@/components/ui/Bits'
import { TeamLogo } from '@/components/ui/Media'
import * as engine from '@/lib/engine'
import { dec, money, signed } from '@/lib/format'
import { CAP } from '@/lib/cap'

export default function Teams() {
  const [conference, setConference] = useState<'all' | 'East' | 'West'>('all')
  const [sort, setSort] = useState<'netRating' | 'offRating' | 'defRating' | 'pace'>('netRating')

  const teams = useMemo(() => {
    return engine.TEAMS
      .filter((t) => conference === 'all' || t.conference === conference)
      .sort((a, b) => (sort === 'defRating' ? a[sort] - b[sort] : b[sort] - a[sort]))
  }, [conference, sort])

  return (
    <PageTransition>
      <SectionTitle title="Teams" sub="Ratings, pace and the cap sheet behind each roster" />

      <div className="mb-5 flex flex-wrap gap-3">
        <Segmented value={conference} onChange={setConference}
          options={[{ value: 'all', label: 'League' }, { value: 'East', label: 'East' }, { value: 'West', label: 'West' }]} />
        <Segmented value={sort} onChange={setSort} options={[
          { value: 'netRating', label: 'Net' }, { value: 'offRating', label: 'Offence' },
          { value: 'defRating', label: 'Defence' }, { value: 'pace', label: 'Pace' },
        ]} />
      </div>

      <motion.div variants={stagger} initial="hidden" animate="show"
        className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {teams.map((t) => {
          const roster = engine.roster(t.teamId)
          const committed = roster.reduce((s, p) => s + p.salary, 0)
          const space = CAP - committed
          return (
            <motion.div key={t.abbr} variants={riseItem}>
              <Link to={`/teams/${t.abbr}`}>
                <GlassCard hover sheen padded={false}
                  className="overflow-hidden"
                  style={{ background: `linear-gradient(150deg, ${t.primaryColor}2E, var(--surface-glass) 60%)` }}>
                  <div className="flex items-center gap-3 p-4">
                    <TeamLogo teamId={t.teamId} abbr={t.abbr} size={52} />
                    <div className="min-w-0 flex-1">
                      <p className="headline text-xl leading-none">{t.fullName}</p>
                      <p className="mt-1 text-[11px] font-semibold uppercase tracking-widest"
                        style={{ color: 'var(--text-2)' }}>
                        {t.conference} · {t.division} · {t.wins}-{t.losses}
                      </p>
                    </div>
                    <span className="num shrink-0 rounded-lg px-2 py-1 text-sm font-bold"
                      style={{
                        background: t.netRating >= 0 ? 'rgba(12,163,12,.16)' : 'rgba(208,59,59,.16)',
                        color: t.netRating >= 0 ? 'var(--good)' : 'var(--bad)',
                      }}>
                      {signed(t.netRating)}
                    </span>
                  </div>
                  <dl className="grid grid-cols-4 border-t text-center" style={{ borderColor: 'var(--border)' }}>
                    {([['OFF', dec(t.offRating)], ['DEF', dec(t.defRating)],
                       ['PACE', dec(t.pace)], ['SPACE', money(space)]] as const).map(([k, v]) => (
                      <div key={k} className="border-r px-1 py-2 last:border-0"
                        style={{ borderColor: 'var(--border)' }}>
                        <dt className="text-[9px] font-bold uppercase tracking-widest"
                          style={{ color: 'var(--text-muted)' }}>{k}</dt>
                        <dd className="num text-sm font-bold">{v}</dd>
                      </div>
                    ))}
                  </dl>
                </GlassCard>
              </Link>
            </motion.div>
          )
        })}
      </motion.div>
    </PageTransition>
  )
}
