import { useMemo, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { motion } from 'framer-motion'
import { PageTransition, riseItem, stagger } from '@/components/ui/PageTransition'
import { GlassCard } from '@/components/ui/GlassCard'
import { Badge, EmptyState, SectionTitle, Segmented, StatTile } from '@/components/ui/Bits'
import { PlayerAvatar, TeamLogo } from '@/components/ui/Media'
import { SkillRadar } from '@/components/charts/SkillRadar'
import { TrendLine } from '@/components/charts/TrendLine'
import { ChartFrame } from '@/components/charts/ChartFrame'
import {
  CartesianGrid, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis,
} from 'recharts'
import { useChartTokens } from '@/lib/palette'
import * as engine from '@/lib/engine'
import { dec, money, shortDate } from '@/lib/format'

const TRENDS = [
  { value: 'pts', label: 'Points' },
  { value: 'reb', label: 'Rebounds' },
  { value: 'ast', label: 'Assists' },
  { value: 'min', label: 'Minutes' },
] as const

export default function PlayerDetail() {
  const { id } = useParams()
  const tokens = useChartTokens()
  const [trend, setTrend] = useState<(typeof TRENDS)[number]['value']>('pts')

  const player = engine.getPlayer(Number(id))
  const data = useMemo(() => {
    if (!player) return null
    const logs = engine.gameLogs(player)
    return {
      logs, career: engine.careerSeasons(player),
      radar: engine.radar(player), splits: engine.splits(logs),
      team: engine.getTeam(player.teamId)!,
    }
  }, [player])

  if (!player || !data) {
    return (
      <PageTransition>
        <EmptyState title="Player not found" hint="Head back to the index and pick another one." />
      </PageTransition>
    )
  }

  const { team, logs, career, radar, splits } = data
  const last10 = logs.slice(-10)
  const seasonAvg = player[trend] as number

  return (
    <PageTransition>
      {/* ------------------------------------------------------------ hero */}
      <motion.section variants={stagger} initial="hidden" animate="show"
        className="relative overflow-hidden rounded-3xl p-6 sm:p-8"
        style={{ background: `linear-gradient(140deg, ${team.primaryColor}38, transparent 62%)` }}>
        <span aria-hidden className="absolute -right-20 -top-24 h-72 w-72 rounded-full opacity-30 blur-[90px]"
          style={{ background: team.primaryColor }} />
        <div className="relative flex flex-col gap-6 sm:flex-row sm:items-end">
          <motion.div variants={riseItem}>
            <PlayerAvatar playerId={player.playerId} name={player.name}
              color={team.primaryColor} size={190} className="rounded-2xl" />
          </motion.div>
          <motion.div variants={riseItem} className="min-w-0 flex-1">
            <Link to={`/teams/${team.abbr}`}
              className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-widest
                         transition-colors hover:text-[var(--brand-lit)]"
              style={{ color: 'var(--text-2)' }}>
              <TeamLogo teamId={team.teamId} abbr={team.abbr} size={20} />
              {team.fullName}
            </Link>
            <h1 className="headline mt-1 text-[clamp(2.25rem,6vw,4.5rem)]">{player.name}</h1>
            <div className="mt-2 flex flex-wrap items-center gap-2">
              <Badge tone="brand">{player.position}</Badge>
              <Badge>{player.age} years old</Badge>
              <Badge>{money(player.salary)} cap hit</Badge>
              <Badge tone={player.surplus >= 0 ? 'good' : 'bad'}>
                {player.surplus >= 0 ? 'Surplus' : 'Overpaid'} {money(Math.abs(player.surplus))}
              </Badge>
            </div>
          </motion.div>
          <motion.div variants={riseItem} className="grid grid-cols-3 gap-2 sm:w-auto">
            <StatTile label="PPG" value={dec(player.pts)} tone="brand" />
            <StatTile label="RPG" value={dec(player.reb)} />
            <StatTile label="APG" value={dec(player.ast)} />
          </motion.div>
        </div>
      </motion.section>

      {/* ------------------------------------------------------- quick nav */}
      <div className="mt-4 flex flex-wrap gap-2">
        <Link to={`/predict/player?player=${player.playerId}`}
          className="rounded-xl bg-gradient-to-br from-[#3B82F6] to-[#1D428A] px-4 py-2.5
                     text-xs font-bold uppercase tracking-widest text-white shadow-glow">
          Project his next game
        </Link>
        <Link to={`/head-to-head?player=${player.playerId}`}
          className="glass glass-hover rounded-xl px-4 py-2.5 text-xs font-bold uppercase tracking-widest">
          Head-to-head history
        </Link>
        <Link to={`/compare?a=${player.playerId}`}
          className="glass glass-hover rounded-xl px-4 py-2.5 text-xs font-bold uppercase tracking-widest">
          Compare with someone
        </Link>
      </div>

      {/* --------------------------------------------------------- content */}
      <div className="mt-6 grid gap-4 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <TrendLine
            title={`Game log — ${TRENDS.find((t) => t.value === trend)!.label}`}
            sub={`Last ${logs.length} games, with the season average marked`}
            data={logs.map((l) => ({
              label: `${shortDate(l.date)} ${l.isHome ? 'vs' : '@'} ${l.opponent}`,
              value: l[trend] as number,
            }))}
            xKey="label"
            series={[{ key: 'value', label: TRENDS.find((t) => t.value === trend)!.label, color: tokens.series[0] }]}
            referenceY={seasonAvg}
            referenceLabel={`Season avg ${dec(seasonAvg)}`}
            height={300}
            table={{
              columns: ['Game', TRENDS.find((t) => t.value === trend)!.label],
              rows: logs.slice(-20).map((l) => [
                `${shortDate(l.date)} ${l.isHome ? 'vs' : '@'} ${l.opponent}`, dec(l[trend] as number),
              ]),
            }}
          />
          <div className="mt-3">
            <Segmented value={trend} onChange={setTrend} options={TRENDS.map((t) => ({ ...t }))} />
          </div>
        </div>

        <SkillRadar
          axes={radar.map((r) => r.axis)}
          series={[{
            name: player.name, color: tokens.series[0],
            values: Object.fromEntries(radar.map((r) => [r.axis, r.value])),
          }]}
          height={320}
        />
      </div>

      {/* ----------------------------------------------------------- splits */}
      <section className="mt-4 grid gap-4 lg:grid-cols-2">
        <GlassCard>
          <SectionTitle title="Situational splits" sub="Where the projection model gets its context" />
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b text-left" style={{ borderColor: 'var(--border)' }}>
                  {['Split', 'GP', 'MIN', 'PTS', 'REB', 'AST'].map((h) => (
                    <th key={h} className="px-2 py-2 text-[11px] font-bold uppercase tracking-widest"
                      style={{ color: 'var(--text-muted)' }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {([['Home', splits.home], ['Away', splits.away],
                   ['2+ days rest', splits.rested], ['Back-to-back', splits.backToBack]] as const)
                  .map(([label, s]) => (
                    <tr key={label} className="border-b last:border-0" style={{ borderColor: 'var(--border)' }}>
                      <td className="px-2 py-2 font-semibold">{label}</td>
                      <td className="num px-2 py-2">{s.gp}</td>
                      <td className="num px-2 py-2">{dec(s.min)}</td>
                      <td className="num px-2 py-2 font-bold">{dec(s.pts)}</td>
                      <td className="num px-2 py-2">{dec(s.reb)}</td>
                      <td className="num px-2 py-2">{dec(s.ast)}</td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
          <p className="mt-3 text-xs" style={{ color: 'var(--text-muted)' }}>
            Home/away and rest are two of the strongest signals in the projection model —
            these rows are the raw version of what it learns.
          </p>
        </GlassCard>

        <ChartFrame
          title="Career progression"
          sub="Season by season, on the standard aging curve"
          height={260}
          series={[
            { key: 'pts', label: 'PTS', color: tokens.series[0] },
            { key: 'reb', label: 'REB', color: tokens.series[2] },
            { key: 'ast', label: 'AST', color: tokens.series[3] },
          ]}
          table={{
            columns: ['Season', 'Age', 'GP', 'PTS', 'REB', 'AST', 'PER', 'VORP'],
            rows: career.map((c) => [c.season, c.age, c.gp, c.pts, c.reb, c.ast, c.per, c.vorp]),
          }}
        >
          <CareerChart career={career} colors={tokens.series} />
        </ChartFrame>
      </section>

      {/* ----------------------------------------------------- recent form */}
      <section className="mt-4">
        <GlassCard>
          <SectionTitle title="Last 10 games" sub="Most recent first" />
          <div className="overflow-x-auto">
            <table className="w-full min-w-[640px] text-sm">
              <thead>
                <tr className="border-b text-left" style={{ borderColor: 'var(--border)' }}>
                  {['Date', 'Matchup', 'MIN', 'PTS', 'REB', 'AST', '3PM', '+/-'].map((h) => (
                    <th key={h} className="px-2 py-2 text-[11px] font-bold uppercase tracking-widest"
                      style={{ color: 'var(--text-muted)' }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {[...last10].reverse().map((l) => (
                  <tr key={l.gameId} className="border-b last:border-0 transition-colors hover-layer-1"
                    style={{ borderColor: 'var(--border)' }}>
                    <td className="px-2 py-2 whitespace-nowrap" style={{ color: 'var(--text-2)' }}>
                      {shortDate(l.date)}
                    </td>
                    <td className="px-2 py-2 whitespace-nowrap font-semibold">
                      {l.isHome ? 'vs' : '@'} {l.opponent}
                    </td>
                    <td className="num px-2 py-2">{dec(l.min)}</td>
                    <td className="num px-2 py-2 font-bold">{l.pts}</td>
                    <td className="num px-2 py-2">{l.reb}</td>
                    <td className="num px-2 py-2">{l.ast}</td>
                    <td className="num px-2 py-2">{l.fg3m}</td>
                    <td className="num px-2 py-2"
                      style={{ color: l.plusMinus >= 0 ? 'var(--good)' : 'var(--bad)' }}>
                      {l.plusMinus > 0 ? '+' : ''}{l.plusMinus}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </GlassCard>
      </section>
    </PageTransition>
  )
}

/** Three series on one shared axis — never a second y-scale. PTS, REB and AST
 *  are all per-game counts, so they belong on the same ruler. */
function CareerChart({ career, colors }: {
  career: ReturnType<typeof engine.careerSeasons>; colors: string[]
}) {
  return (
    <ResponsiveContainer width="100%" height="100%">
      <LineChart data={career} margin={{ top: 8, right: 12, bottom: 0, left: -18 }}>
        <CartesianGrid stroke="var(--grid)" vertical={false} />
        <XAxis dataKey="season" tick={{ fill: 'var(--text-muted)', fontSize: 11 }} tickLine={false} />
        <YAxis tick={{ fill: 'var(--text-muted)', fontSize: 11 }} tickLine={false} axisLine={false} width={40} />
        <Tooltip contentStyle={{ background: 'var(--surface)', border: '1px solid var(--border)',
          borderRadius: 10, fontSize: 12 }} />
        <Line type="monotone" dataKey="pts" name="PTS" stroke={colors[0]} strokeWidth={2} dot={{ r: 3 }} />
        <Line type="monotone" dataKey="reb" name="REB" stroke={colors[2]} strokeWidth={2} dot={{ r: 3 }} />
        <Line type="monotone" dataKey="ast" name="AST" stroke={colors[3]} strokeWidth={2} dot={{ r: 3 }} />
      </LineChart>
    </ResponsiveContainer>
  )
}
