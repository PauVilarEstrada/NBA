import { useEffect, useMemo, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { motion } from 'framer-motion'
import { PageTransition } from '@/components/ui/PageTransition'
import { GlassCard } from '@/components/ui/GlassCard'
import { EmptyState, SectionTitle } from '@/components/ui/Bits'
import { PlayerPicker } from '@/components/ui/Pickers'
import { PlayerAvatar, TeamLogo } from '@/components/ui/Media'
import { SkillRadar } from '@/components/charts/SkillRadar'
import { CompareBars } from '@/components/charts/CompareBars'
import { useChartTokens } from '@/lib/palette'
import * as engine from '@/lib/engine'
import { dec, money } from '@/lib/format'
import type { Player } from '@/types'

const SLOTS = 4

/** Rows the comparison is built from. `higherIsBetter: false` matters — the
 *  winner highlight would otherwise reward the player who turns it over most. */
const ROWS: Array<{ key: keyof Player; label: string; fmt: (v: number) => string; higherIsBetter: boolean }> = [
  { key: 'pts', label: 'Points', fmt: (v) => dec(v), higherIsBetter: true },
  { key: 'reb', label: 'Rebounds', fmt: (v) => dec(v), higherIsBetter: true },
  { key: 'ast', label: 'Assists', fmt: (v) => dec(v), higherIsBetter: true },
  { key: 'stl', label: 'Steals', fmt: (v) => dec(v, 1), higherIsBetter: true },
  { key: 'blk', label: 'Blocks', fmt: (v) => dec(v, 1), higherIsBetter: true },
  { key: 'tov', label: 'Turnovers', fmt: (v) => dec(v, 1), higherIsBetter: false },
  { key: 'fg3m', label: '3PM', fmt: (v) => dec(v, 1), higherIsBetter: true },
  { key: 'min', label: 'Minutes', fmt: (v) => dec(v), higherIsBetter: true },
  { key: 'ts', label: 'True shooting', fmt: (v) => `${(v * 100).toFixed(1)}%`, higherIsBetter: true },
  { key: 'usg', label: 'Usage', fmt: (v) => `${(v * 100).toFixed(1)}%`, higherIsBetter: true },
  { key: 'marketPrice', label: 'Market value', fmt: (v) => money(v), higherIsBetter: true },
]

export default function ComparePlayers() {
  const tokens = useChartTokens()
  const [params, setParams] = useSearchParams()
  const [picks, setPicks] = useState<Array<Player | null>>(() => {
    const seeded = ['a', 'b', 'c', 'd'].map((k) => {
      const id = Number(params.get(k))
      return id ? engine.getPlayer(id) ?? null : null
    })
    if (!seeded.some(Boolean)) {
      const top = [...engine.PLAYERS].sort((x, y) => y.pts - x.pts)
      return [top[0], top[1], null, null]
    }
    return seeded
  })

  useEffect(() => {
    const next = new URLSearchParams()
    picks.forEach((p, i) => { if (p) next.set(['a', 'b', 'c', 'd'][i], String(p.playerId)) })
    setParams(next, { replace: true })
  }, [picks, setParams])

  const chosen = picks.filter(Boolean) as Player[]
  const radars = useMemo(() => chosen.map((p) => engine.radar(p)), [chosen])
  const axes = radars[0]?.map((r) => r.axis) ?? []

  const set = (i: number, p: Player | null) =>
    setPicks((prev) => prev.map((x, j) => (j === i ? p : x)))

  return (
    <PageTransition>
      <SectionTitle title="Compare players"
        sub="Up to four at once. Every axis uses the same scale, so the shapes are comparable." />

      <div className="mb-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {Array.from({ length: SLOTS }).map((_, i) => (
          <PlayerPicker
            key={i} value={picks[i] ?? null} onChange={(p) => set(i, p)}
            placeholder={i < 2 ? 'Pick a player…' : 'Add another (optional)…'}
            exclude={chosen.map((p) => p.playerId)}
          />
        ))}
      </div>

      {chosen.length < 2 ? (
        <EmptyState title="Pick at least two players" hint="Use the boxes above — type a surname and hit Enter." />
      ) : (
        <>
          <div className="grid gap-4 lg:grid-cols-2">
            <SkillRadar
              axes={axes}
              series={chosen.map((p, i) => ({
                name: p.name, color: tokens.series[i],
                values: Object.fromEntries(radars[i].map((r) => [r.axis, r.value])),
              }))}
              height={360}
              title="Skill profiles overlaid"
            />
            <CompareBars
              title="Per-game production"
              sub="Same axis for every player — no rescaling tricks"
              height={360}
              data={ROWS.slice(0, 8).map((r) => ({
                label: r.label,
                ...Object.fromEntries(chosen.map((p) => [p.name, Number(p[r.key])])),
              }))}
              series={chosen.map((p, i) => ({ key: p.name, label: p.name, color: tokens.series[i] }))}
              table={{
                columns: ['Stat', ...chosen.map((p) => p.name)],
                rows: ROWS.slice(0, 8).map((r) => [r.label, ...chosen.map((p) => r.fmt(Number(p[r.key])))]),
              }}
            />
          </div>

          <GlassCard className="mt-4 overflow-hidden p-0">
            <div className="overflow-x-auto">
              <table className="w-full min-w-[640px]">
                <thead>
                  <tr style={{ background: 'rgba(255,255,255,.03)' }}>
                    <th className="px-4 py-3 text-left text-[11px] font-bold uppercase tracking-widest"
                      style={{ color: 'var(--text-muted)' }}>Stat</th>
                    {chosen.map((p, i) => {
                      const team = engine.getTeam(p.teamId)!
                      return (
                        <th key={p.playerId} className="px-4 py-3 text-left">
                          <span className="flex items-center gap-2">
                            <PlayerAvatar playerId={p.playerId} name={p.name}
                              color={team.primaryColor} size={36} ring={false} />
                            <span className="min-w-0">
                              <span className="block truncate font-display text-base font-bold leading-tight">
                                {p.name}
                              </span>
                              <span className="flex items-center gap-1 text-[10px] font-medium"
                                style={{ color: 'var(--text-muted)' }}>
                                <TeamLogo teamId={team.teamId} abbr={team.abbr} size={12} />
                                {team.abbr}
                              </span>
                            </span>
                            <span aria-hidden className="ml-auto h-6 w-1 rounded-full"
                              style={{ background: tokens.series[i] }} />
                          </span>
                        </th>
                      )
                    })}
                  </tr>
                </thead>
                <tbody>
                  {ROWS.map((row) => {
                    const values = chosen.map((p) => Number(p[row.key]))
                    const best = row.higherIsBetter ? Math.max(...values) : Math.min(...values)
                    return (
                      <tr key={String(row.key)} className="border-t" style={{ borderColor: 'var(--border)' }}>
                        <td className="px-4 py-2.5 text-sm font-semibold" style={{ color: 'var(--text-2)' }}>
                          {row.label}
                        </td>
                        {chosen.map((p, i) => {
                          const v = Number(p[row.key])
                          const isBest = v === best && chosen.length > 1
                          return (
                            <td key={p.playerId} className="px-4 py-2.5">
                              <motion.span layout
                                className="num inline-flex items-center gap-1.5 rounded-lg px-2 py-1 text-sm font-bold"
                                style={isBest
                                  ? { background: `${tokens.series[i]}22`, color: tokens.series[i] }
                                  : {}}>
                                {row.fmt(v)}
                                {isBest && <span aria-label="best" className="text-[10px]">▲</span>}
                              </motion.span>
                            </td>
                          )
                        })}
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          </GlassCard>
        </>
      )}
    </PageTransition>
  )
}
