import { useMemo, useState } from 'react'
import { motion } from 'framer-motion'
import { PageTransition, riseItem, stagger } from '@/components/ui/PageTransition'
import { EmptyState, SectionTitle, Segmented } from '@/components/ui/Bits'
import { PlayerCard } from '@/components/player/PlayerCard'
import * as engine from '@/lib/engine'

const SORTS = [
  { value: 'pts', label: 'Points' },
  { value: 'reb', label: 'Rebounds' },
  { value: 'ast', label: 'Assists' },
  { value: 'marketPrice', label: 'Value' },
] as const
type SortKey = (typeof SORTS)[number]['value']

export default function Players() {
  const [query, setQuery] = useState('')
  const [sort, setSort] = useState<SortKey>('pts')
  const [conference, setConference] = useState<'all' | 'East' | 'West'>('all')

  const results = useMemo(() => {
    const base = query.trim() ? engine.searchPlayers(query, 200) : engine.PLAYERS
    return [...base]
      .filter((p) => conference === 'all' || engine.getTeam(p.teamId)?.conference === conference)
      .sort((a, b) => (b[sort] as number) - (a[sort] as number))
  }, [query, sort, conference])

  return (
    <PageTransition>
      <SectionTitle
        title="Player index"
        sub={`${results.length} players · click a card for the full profile`}
      />

      {/* filters live in one row above the results, never interleaved with them */}
      <div className="mb-5 flex flex-wrap items-center gap-3">
        <div className="relative min-w-[220px] flex-1">
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search by name, team or position…"
            className="glass w-full rounded-xl px-4 py-3 pl-10 text-sm outline-none
                       placeholder:text-[var(--text-muted)] focus:ring-2 focus:ring-[#3B82F6]/50"
          />
          <svg viewBox="0 0 24 24" className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 opacity-45"
            fill="none" stroke="currentColor" strokeWidth="2">
            <circle cx="11" cy="11" r="7" /><path d="m20 20-3.5-3.5" />
          </svg>
        </div>
        <Segmented value={conference} onChange={setConference}
          options={[{ value: 'all', label: 'All' }, { value: 'East', label: 'East' }, { value: 'West', label: 'West' }]} />
        <Segmented value={sort} onChange={setSort} options={SORTS.map((s) => ({ ...s }))} />
      </div>

      {results.length === 0 ? (
        <EmptyState title="No players match that" hint="Try a surname, a team code like BOS, or a position." />
      ) : (
        <motion.div variants={stagger} initial="hidden" animate="show"
          className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {results.slice(0, 60).map((p) => (
            <motion.div key={p.playerId} variants={riseItem}>
              <PlayerCard player={p} />
            </motion.div>
          ))}
        </motion.div>
      )}
    </PageTransition>
  )
}
