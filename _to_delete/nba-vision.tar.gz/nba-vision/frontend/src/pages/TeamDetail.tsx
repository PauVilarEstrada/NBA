import { useMemo, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { motion } from 'framer-motion'
import { PageTransition, riseItem, stagger } from '@/components/ui/PageTransition'
import { GlassCard } from '@/components/ui/GlassCard'
import { Badge, EmptyState, SectionTitle, StatTile } from '@/components/ui/Bits'
import { PlayerAvatar, TeamLogo } from '@/components/ui/Media'
import { CompareBars } from '@/components/charts/CompareBars'
import { TeamPicker } from '@/components/ui/Pickers'
import { useChartTokens } from '@/lib/palette'
import * as engine from '@/lib/engine'
import { CAP, LUXURY_TAX } from '@/lib/cap'
import { dec, money, signed } from '@/lib/format'
import type { Team } from '@/types'

export default function TeamDetail() {
  const { abbr } = useParams()
  const tokens = useChartTokens()
  const team = engine.getTeam(String(abbr).toUpperCase())
  const [rival, setRival] = useState<Team | null>(null)

  const data = useMemo(() => {
    if (!team) return null
    const roster = engine.roster(team.teamId)
    const committed = roster.reduce((s, p) => s + p.salary, 0)
    return { roster, committed, space: CAP - committed, tax: Math.max(0, committed - LUXURY_TAX) }
  }, [team])

  if (!team || !data) {
    return <PageTransition><EmptyState title="Team not found" /></PageTransition>
  }

  const { roster, committed, space, tax } = data
  const capPct = Math.min(100, (committed / CAP) * 100)

  const axes = [
    { label: 'Offence', key: 'offRating' as const },
    { label: 'Defence*', key: 'defRating' as const },
    { label: 'Net', key: 'netRating' as const },
    { label: 'Pace', key: 'pace' as const },
    { label: 'Win %', key: 'winPct' as const },
  ]

  return (
    <PageTransition>
      <motion.section variants={stagger} initial="hidden" animate="show"
        className="relative overflow-hidden rounded-3xl p-6 sm:p-8"
        style={{ background: `linear-gradient(135deg, ${team.primaryColor}44, ${team.secondaryColor}18 55%, transparent)` }}>
        <span aria-hidden className="absolute -right-24 -top-24 h-80 w-80 rounded-full opacity-25 blur-[100px]"
          style={{ background: team.primaryColor }} />
        <motion.div variants={riseItem} className="relative flex flex-wrap items-center gap-5">
          <TeamLogo teamId={team.teamId} abbr={team.abbr} size={104} />
          <div>
            <p className="eyebrow">{team.conference} · {team.division}</p>
            <h1 className="headline text-[clamp(2rem,5.5vw,4rem)]">{team.fullName}</h1>
            <div className="mt-2 flex flex-wrap gap-2">
              <Badge tone="brand">{team.wins}-{team.losses}</Badge>
              <Badge tone={team.netRating >= 0 ? 'good' : 'bad'}>Net {signed(team.netRating)}</Badge>
              <Badge>#{team.netRatingRank} in the league</Badge>
            </div>
          </div>
          <div className="ml-auto grid grid-cols-2 gap-2 sm:grid-cols-4">
            <StatTile label="Offence" value={dec(team.offRating)} tone="brand" hint="per 100" />
            <StatTile label="Defence" value={dec(team.defRating)} hint="per 100" />
            <StatTile label="Pace" value={dec(team.pace)} hint="poss/48" />
            <StatTile label="Cap space" value={money(space)} tone={space >= 0 ? 'neutral' : 'accent'} />
          </div>
        </motion.div>
      </motion.section>

      <div className="mt-6 grid gap-4 lg:grid-cols-3">
        {/* ------------------------------------------------------ cap sheet */}
        <GlassCard>
          <SectionTitle title="Cap sheet" sub={`${engine.SEASON}-${String(engine.SEASON + 1).slice(2)} commitments`} />
          <div className="mb-4">
            <div className="mb-1.5 flex justify-between text-xs">
              <span style={{ color: 'var(--text-2)' }}>Committed</span>
              <span className="num font-bold">{money(committed)} / {money(CAP)}</span>
            </div>
            <div className="relative h-3 overflow-hidden rounded-full layer-2">
              <motion.div initial={{ width: 0 }} animate={{ width: `${capPct}%` }}
                transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
                className="h-full rounded-full"
                style={{ background: `linear-gradient(90deg, ${team.primaryColor}, ${tokens.series[0]})` }} />
              <span aria-hidden className="absolute inset-y-0 w-px layer-10"
                style={{ left: `${(LUXURY_TAX / CAP) * 100}%` }} title="Luxury tax line" />
            </div>
            <p className="mt-1.5 text-[11px]" style={{ color: 'var(--text-muted)' }}>
              The white marker is the luxury-tax line ({money(LUXURY_TAX)}).
              {tax > 0 ? ` This roster is ${money(tax)} into the tax.` : ' This roster is under it.'}
            </p>
          </div>
          <ul className="space-y-1.5">
            {roster.map((p) => (
              <li key={p.playerId} className="flex items-center gap-2 text-sm">
                <Link to={`/players/${p.playerId}`} className="min-w-0 flex-1 truncate hover:text-[var(--brand-lit)]">
                  {p.name}
                </Link>
                <span className="num font-semibold">{money(p.salary)}</span>
                <span className="num w-16 text-right text-[11px]"
                  style={{ color: p.surplus >= 0 ? 'var(--good)' : 'var(--bad)' }}>
                  {p.surplus >= 0 ? '+' : '−'}{money(Math.abs(p.surplus))}
                </span>
              </li>
            ))}
          </ul>
          <p className="mt-3 text-[11px]" style={{ color: 'var(--text-muted)' }}>
            The right column is surplus value: what the model thinks he is worth, minus what he is paid.
          </p>
        </GlassCard>

        {/* -------------------------------------------------------- roster */}
        <div className="lg:col-span-2">
          <SectionTitle title="Roster" sub={`${roster.length} players in the index`} />
          <motion.div variants={stagger} initial="hidden" animate="show"
            className="grid gap-3 sm:grid-cols-2">
            {roster.map((p) => (
              <motion.div key={p.playerId} variants={riseItem}>
                <Link to={`/players/${p.playerId}`}>
                  <GlassCard hover padded={false} className="flex items-center gap-3 p-3">
                    <PlayerAvatar playerId={p.playerId} name={p.name} color={team.primaryColor} size={56} />
                    <div className="min-w-0 flex-1">
                      <p className="truncate font-display text-lg font-bold leading-tight">{p.name}</p>
                      <p className="text-[11px]" style={{ color: 'var(--text-muted)' }}>
                        {p.position} · {p.age} yrs · {money(p.salary)}
                      </p>
                    </div>
                    <dl className="num flex gap-3 text-center">
                      {([['PTS', p.pts], ['REB', p.reb], ['AST', p.ast]] as const).map(([k, v]) => (
                        <div key={k}>
                          <dt className="text-[9px] font-bold tracking-widest"
                            style={{ color: 'var(--text-muted)' }}>{k}</dt>
                          <dd className="text-sm font-bold">{dec(v)}</dd>
                        </div>
                      ))}
                    </dl>
                  </GlassCard>
                </Link>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </div>

      {/* --------------------------------------------------------- compare */}
      <section className="mt-6">
        <SectionTitle title="Compare with another team"
          sub="Pick a rival to put the two profiles on the same axes"
          right={<div className="w-64"><TeamPicker value={rival} onChange={setRival} /></div>} />
        {rival && rival.abbr !== team.abbr && (
          <div className="grid gap-4 lg:grid-cols-2">
            <CompareBars
              title="Team profile"
              sub="*Lower is better for defensive rating"
              height={300}
              data={axes.map((a) => ({
                label: a.label,
                [team.abbr]: a.key === 'winPct' ? Number((team[a.key] * 100).toFixed(1)) : Number(team[a.key]),
                [rival.abbr]: a.key === 'winPct' ? Number((rival[a.key] * 100).toFixed(1)) : Number(rival[a.key]),
              }))}
              series={[
                { key: team.abbr, label: team.fullName, color: tokens.series[0] },
                { key: rival.abbr, label: rival.fullName, color: tokens.series[1] },
              ]}
              table={{
                columns: ['Metric', team.abbr, rival.abbr],
                rows: axes.map((a) => [a.label, String(team[a.key]), String(rival[a.key])]),
              }}
            />
            <GlassCard>
              <SectionTitle title="Rosters side by side" />
              <div className="grid grid-cols-2 gap-4 text-sm">
                {[team, rival].map((t, i) => (
                  <div key={t.abbr}>
                    <p className="mb-2 flex items-center gap-1.5 font-display text-base font-bold">
                      <span aria-hidden className="h-3 w-1 rounded" style={{ background: tokens.series[i] }} />
                      <TeamLogo teamId={t.teamId} abbr={t.abbr} size={18} /> {t.abbr}
                    </p>
                    <ul className="space-y-1">
                      {engine.roster(t.teamId).map((p) => (
                        <li key={p.playerId} className="flex justify-between gap-2">
                          <Link to={`/players/${p.playerId}`} className="truncate hover:text-[var(--brand-lit)]">
                            {p.name}
                          </Link>
                          <span className="num font-semibold">{dec(p.pts)}</span>
                        </li>
                      ))}
                    </ul>
                    <p className="mt-2 border-t pt-2 text-xs" style={{ borderColor: 'var(--border)' }}>
                      Payroll <b className="num">{money(engine.roster(t.teamId).reduce((s, p) => s + p.salary, 0))}</b>
                    </p>
                  </div>
                ))}
              </div>
              <Link to={`/predict/team?home=${team.abbr}&away=${rival.abbr}`}
                className="mt-4 block rounded-xl bg-gradient-to-br from-[#3B82F6] to-[#1D428A] py-2.5
                           text-center text-xs font-bold uppercase tracking-widest text-white">
                Forecast {team.abbr} vs {rival.abbr}
              </Link>
            </GlassCard>
          </div>
        )}
      </section>
    </PageTransition>
  )
}
