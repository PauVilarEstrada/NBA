export interface Team {
  teamId: number
  abbr: string
  city: string
  name: string
  fullName: string
  conference: 'East' | 'West'
  division: string
  primaryColor: string
  secondaryColor: string
  logo: string
  offRating: number
  defRating: number
  netRating: number
  pace: number
  wins: number
  losses: number
  winPct: number
  netRatingRank: number
  defVsPosition: Record<string, number>
}

export interface Player {
  playerId: number
  name: string
  firstName: string
  lastName: string
  slug: string
  team: string
  teamId: number
  position: string
  age: number
  min: number
  pts: number
  reb: number
  ast: number
  stl: number
  blk: number
  tov: number
  fg3m: number
  ts: number
  usg: number
  salary: number
  estimatedValue: number
  marketPrice: number
  valueIndex: number
  surplus: number
  leagueMax: number
  headshot: string
  teamLogo: string
}

export interface GameLog {
  gameId: string
  date: string
  opponent: string
  opponentId: number
  isHome: boolean
  restDays: number
  pts: number
  reb: number
  ast: number
  stl: number
  blk: number
  tov: number
  fg3m: number
  min: number
  ts: number
  plusMinus: number
}

export interface SeasonRow {
  season: string
  seasonStart: number
  age: number
  team: string
  gp: number
  min: number
  pts: number
  reb: number
  ast: number
  stl: number
  blk: number
  tov: number
  fg3m: number
  ts: number
  per: number
  ws: number
  bpm: number
  vorp: number
}

export interface Distribution {
  mean: number
  median: number
  low: number
  high: number
  p10: number
  p90: number
  quantiles: Record<string, number>
  line?: number
  probOver?: number
  probUnder?: number
}

export interface Driver {
  label: string
  detail: string
  impact: number
}

export interface PlayerPrediction {
  player: Player
  opponent: Team
  context: {
    venue: 'home' | 'away'
    restDays: number
    seasonType: 'regular' | 'playoffs'
    formIndex: number
    matchupDefVsPosition: number
  }
  projections: Record<string, Distribution>
  drivers: Driver[]
  source: 'model' | 'mock'
}

export interface TeamPrediction {
  home: Team
  away: Team
  seasonType: 'regular' | 'playoffs'
  projection: {
    homePts: Distribution
    awayPts: Distribution
    margin: Distribution
    total: Distribution
    homeWinProb: number
    awayWinProb: number
    possessions: number
    spread: number
  }
  contributions: Array<{
    playerId: number; name: string; team: string; headshot: string
    pts: number; reb: number; ast: number; min: number
  }>
  series?: { homeWinsSeries: number; gameHomeProb: number; gameAwayProb: number; format: string }
  source: 'model' | 'mock'
}

export interface H2HGame {
  season: string
  date: string
  isHome: boolean
  pts: number
  reb: number
  ast: number
  min: number
}

export interface BoxRow {
  playerId: number; name: string; team: string; min: number
  pts: number; reb: number; ast: number; stl: number; blk: number; tov: number
  fgm: number; fga: number; tpm: number; tpa: number; ftm: number; fta: number
  isFiller?: boolean
}

export interface SimEvent {
  clockSeconds: number
  period: number
  periodClock: string
  team: string
  kind: 'shot_made' | 'shot_miss' | 'turnover' | 'rebound' | 'ft' | 'period'
  text: string
  homeScore: number
  awayScore: number
  playerId: number | null
  /** Secondary actors, so a live box score can be rebuilt exactly from the
   *  event stream instead of being guessed from the play text. */
  assistPlayerId?: number | null
  defenderPlayerId?: number | null
  points: number
  highlight: boolean
}

export interface SimResult {
  final: { home: number; away: number; periods: number; overtime: number }
  home: { teamId: number | string; name: string; abbr: string; score: number; box: BoxRow[]; logo?: string; color?: string }
  away: { teamId: number | string; name: string; abbr: string; score: number; box: BoxRow[]; logo?: string; color?: string }
  events: SimEvent[]
  durationSeconds: number
  userSide: 'home' | 'away'
  seed: number
  isPlayoffs: boolean
  distribution?: {
    runs: number; homeWinProb: number; marginMean: number; marginStd: number
    marginP10: number; marginP90: number; totalMean: number
  }
}

export interface PricedPlayer extends Player {
  cost: number
  costPct: number
  efficiency: number
}
