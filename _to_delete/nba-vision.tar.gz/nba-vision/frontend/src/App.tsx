import { Route, Routes, useLocation } from 'react-router-dom'
import { AnimatePresence } from 'framer-motion'
import { AppShell } from '@/components/layout/AppShell'
import Home from '@/pages/Home'
import Players from '@/pages/Players'
import PlayerDetail from '@/pages/PlayerDetail'
import ComparePlayers from '@/pages/ComparePlayers'
import Teams from '@/pages/Teams'
import TeamDetail from '@/pages/TeamDetail'
import HeadToHead from '@/pages/HeadToHead'
import PredictPlayer from '@/pages/PredictPlayer'
import PredictTeam from '@/pages/PredictTeam'
import Builder from '@/pages/Builder'
import NotFound from '@/pages/NotFound'

export default function App() {
  const location = useLocation()
  return (
    <AppShell>
      <AnimatePresence mode="wait">
        <Routes location={location} key={location.pathname}>
          <Route path="/" element={<Home />} />
          <Route path="/players" element={<Players />} />
          <Route path="/players/:id" element={<PlayerDetail />} />
          <Route path="/compare" element={<ComparePlayers />} />
          <Route path="/teams" element={<Teams />} />
          <Route path="/teams/:abbr" element={<TeamDetail />} />
          <Route path="/head-to-head" element={<HeadToHead />} />
          <Route path="/predict/player" element={<PredictPlayer />} />
          <Route path="/predict/team" element={<PredictTeam />} />
          <Route path="/builder" element={<Builder />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </AnimatePresence>
    </AppShell>
  )
}
