import { useEffect, useState } from 'react'
import { motion } from 'framer-motion'

const STEPS = [
  'Locking rosters',
  'Pulling opponent ratings',
  'Allocating minutes by usage',
  'Running possession model',
  'Warming up',
]

/** Pre-game loader. It is not decoration: the simulation genuinely runs a few
 *  hundred possessions plus the Monte Carlo sweep, and naming the stage tells
 *  the user what is happening instead of showing an anonymous spinner. */
export function GameLoader({ opponent, onDone, duration = 3200 }: {
  opponent: string; onDone: () => void; duration?: number
}) {
  const [step, setStep] = useState(0)

  useEffect(() => {
    const per = duration / STEPS.length
    const id = setInterval(() => setStep((s) => s + 1), per)
    const done = setTimeout(onDone, duration)
    return () => { clearInterval(id); clearTimeout(done) }
  }, [duration, onDone])

  return (
    <div className="glass flex flex-col items-center justify-center rounded-2xl px-6 py-20 text-center">
      <div className="relative mb-8 h-24 w-24">
        <motion.span
          className="absolute inset-0 rounded-full border-2 border-[#3B82F6]/60"
          animate={{ rotate: 360 }} transition={{ duration: 2.6, repeat: Infinity, ease: 'linear' }} />
        <motion.span
          className="absolute inset-3 rounded-full border-2 border-[#C8102E]/60"
          animate={{ rotate: -360 }} transition={{ duration: 1.8, repeat: Infinity, ease: 'linear' }} />
        <motion.span
          className="absolute inset-0 grid place-items-center"
          animate={{ y: [0, -14, 0], scale: [1, 0.94, 1] }}
          transition={{ duration: 0.72, repeat: Infinity, ease: 'easeInOut' }}>
          <span className="block h-8 w-8 rounded-full bg-gradient-to-br from-[#E5484D] to-[#8A2418]
                           shadow-[0_0_20px_4px_rgba(229,72,77,.35)]" />
        </motion.span>
      </div>

      <p className="headline text-3xl">Tip-off vs {opponent}</p>
      <p className="mt-1 text-sm" style={{ color: 'var(--text-2)' }}>
        {STEPS[Math.min(step, STEPS.length - 1)]}…
      </p>

      <div className="mt-6 h-1 w-64 overflow-hidden rounded-full layer-2">
        <motion.div className="h-full rounded-full bg-gradient-to-r from-[#3B82F6] to-[#C8102E]"
          initial={{ width: '0%' }} animate={{ width: '100%' }}
          transition={{ duration: duration / 1000, ease: 'easeInOut' }} />
      </div>
    </div>
  )
}
