import { useEffect, useState } from 'react'
import { NavLink, useLocation } from 'react-router-dom'
import { AnimatePresence, motion } from 'framer-motion'
import clsx from 'clsx'
import { useTheme } from '@/store/theme'
import { dataMode } from '@/lib/api'
import { Badge } from '@/components/ui/Bits'

const NAV = [
  { to: '/', label: 'Home', end: true },
  { to: '/players', label: 'Players' },
  { to: '/compare', label: 'Compare' },
  { to: '/teams', label: 'Teams' },
  { to: '/head-to-head', label: 'Head-to-head' },
  { to: '/predict/player', label: 'Player projection' },
  { to: '/predict/team', label: 'Game forecast' },
  { to: '/builder', label: 'Build a team' },
]

export function AppShell({ children }: { children: React.ReactNode }) {
  const { theme, toggle } = useTheme()
  const [scrolled, setScrolled] = useState(false)
  const [menuOpen, setMenuOpen] = useState(false)
  const location = useLocation()

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8)
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  useEffect(() => { setMenuOpen(false); window.scrollTo({ top: 0 }) }, [location.pathname])

  return (
    <div className="min-h-full">
      <header
        className={clsx('sticky top-0 z-50 transition-all duration-300',
          scrolled && 'backdrop-blur-xl')}
        style={{
          background: scrolled ? 'color-mix(in srgb, var(--bg) 78%, transparent)' : 'transparent',
          borderBottom: `1px solid ${scrolled ? 'var(--border)' : 'transparent'}`,
        }}
      >
        <div className="mx-auto flex max-w-[1400px] items-center gap-4 px-4 py-3 sm:px-6 lg:px-8">
          <NavLink to="/" className="group flex shrink-0 items-center gap-2.5">
            <Rings />
            <span className="headline text-xl leading-none">
              NBA<span className="text-[var(--accent-lit)]">·</span>VISION
            </span>
          </NavLink>

          <nav className="ml-2 hidden flex-1 items-center gap-0.5 lg:flex">
            {NAV.map((item) => (
              <NavLink key={item.to} to={item.to} end={item.end}
                className={({ isActive }) => clsx(
                  'relative rounded-lg px-3 py-2 text-[13px] font-semibold transition-colors',
                  isActive ? 'text-[var(--text)]' : 'text-[var(--text-2)] hover:text-[var(--text)]')}
              >
                {({ isActive }) => (
                  <>
                    {isActive && (
                      <motion.span layoutId="nav-pill"
                        className="absolute inset-0 rounded-lg layer-2 ring-1 ring-[var(--border)]"
                        transition={{ type: 'spring', stiffness: 400, damping: 34 }} />
                    )}
                    <span className="relative z-10">{item.label}</span>
                  </>
                )}
              </NavLink>
            ))}
          </nav>

          <div className="ml-auto flex items-center gap-2">
            <Badge tone={dataMode === 'live' ? 'good' : 'brand'}>
              {dataMode === 'live' ? 'Live API' : 'Demo data'}
            </Badge>
            <button
              onClick={toggle}
              aria-label={`Switch to ${theme === 'dark' ? 'light' : 'dark'} theme`}
              className="glass grid h-9 w-9 place-items-center rounded-lg transition-colors hover-layer-2"
            >
              <AnimatePresence mode="wait" initial={false}>
                <motion.span key={theme}
                  initial={{ opacity: 0, rotate: -60, scale: 0.6 }}
                  animate={{ opacity: 1, rotate: 0, scale: 1 }}
                  exit={{ opacity: 0, rotate: 60, scale: 0.6 }}
                  transition={{ duration: 0.22 }}
                >
                  {theme === 'dark' ? <SunIcon /> : <MoonIcon />}
                </motion.span>
              </AnimatePresence>
            </button>
            <button
              onClick={() => setMenuOpen((v) => !v)}
              aria-label="Menu" aria-expanded={menuOpen}
              className="glass grid h-9 w-9 place-items-center rounded-lg lg:hidden"
            >
              <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2">
                <path d={menuOpen ? 'M6 6l12 12M18 6L6 18' : 'M4 7h16M4 12h16M4 17h16'} />
              </svg>
            </button>
          </div>
        </div>

        <AnimatePresence>
          {menuOpen && (
            <motion.nav
              initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.24, ease: [0.22, 1, 0.36, 1] }}
              className="overflow-hidden border-t lg:hidden" style={{ borderColor: 'var(--border)' }}
            >
              <ul className="mx-auto max-w-[1400px] px-4 py-2 sm:px-6">
                {NAV.map((item) => (
                  <li key={item.to}>
                    <NavLink to={item.to} end={item.end}
                      className={({ isActive }) => clsx('block rounded-lg px-3 py-2.5 text-sm font-semibold',
                        isActive ? 'layer-2 text-[var(--text)]' : 'text-[var(--text-2)]')}>
                      {item.label}
                    </NavLink>
                  </li>
                ))}
              </ul>
            </motion.nav>
          )}
        </AnimatePresence>
      </header>

      {children}

      <footer className="border-t py-8" style={{ borderColor: 'var(--border)' }}>
        <div className="mx-auto max-w-[1400px] px-4 text-xs sm:px-6 lg:px-8"
          style={{ color: 'var(--text-muted)' }}>
          <p className="mb-1">
            <b className="text-[var(--text-2)]">NBA Vision</b> — a portfolio project.
            Not affiliated with or endorsed by the NBA.
          </p>
          <p>
            Data sources: stats.nba.com (via nba_api), Basketball-Reference, Spotrac,
            HoopsHype, RealGM. Player and team imagery © NBA, served from cdn.nba.com.
            {dataMode === 'demo' && ' Running on the built-in demo dataset — projections come from the calibrated baseline model.'}
          </p>
        </div>
      </footer>
    </div>
  )
}

/** A small orbiting mark: a ball, and the two rings of a projection interval. */
function Rings() {
  return (
    <span className="relative grid h-8 w-8 place-items-center">
      <span className="absolute inset-0 rounded-full border border-[var(--brand-lit)]/40 animate-spinSlow" />
      <span className="absolute inset-1.5 rounded-full border border-[var(--accent-lit)]/50" />
      <span className="h-2 w-2 rounded-full bg-gradient-to-br from-[#3B82F6] to-[#C8102E]
                       shadow-[0_0_12px_2px_rgba(59,130,246,.55)]" />
    </span>
  )
}

const SunIcon = () => (
  <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="1.9">
    <circle cx="12" cy="12" r="4" />
    <path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4" />
  </svg>
)
const MoonIcon = () => (
  <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="1.9">
    <path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8Z" />
  </svg>
)
