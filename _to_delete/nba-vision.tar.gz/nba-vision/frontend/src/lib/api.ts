/**
 * Single data-access layer.
 *
 * `VITE_API_URL` unset  -> the offline engine in `lib/engine.ts` (demo mode).
 * `VITE_API_URL` set    -> the FastAPI backend, which proxies stats.nba.com,
 *                          reads Postgres and serves the trained models.
 *
 * Both paths return the same shapes, so no component knows or cares which is
 * live. `dataMode` is exposed so the UI can badge projections honestly.
 */
import * as engine from './engine'
import type {
  GameLog, H2HGame, Player, PlayerPrediction, PricedPlayer, SeasonRow,
  SimResult, Team, TeamPrediction,
} from '@/types'

const BASE = (import.meta.env.VITE_API_URL as string | undefined)?.replace(/\/$/, '')
export const isLive = Boolean(BASE)
export const dataMode: 'live' | 'demo' = isLive ? 'live' : 'demo'

async function get<T>(path: string): Promise<T> {
  const res = await fetch(`${BASE}${path}`)
  if (!res.ok) throw new Error(`${res.status} ${res.statusText}`)
  return res.json() as Promise<T>
}

async function post<T>(path: string, body: unknown): Promise<T> {
  const res = await fetch(`${BASE}${path}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  })
  if (!res.ok) throw new Error(`${res.status} ${res.statusText}`)
  return res.json() as Promise<T>
}

/** A tiny artificial delay in demo mode. Not decoration: it keeps loading
 *  states on the real code path so they are exercised, not dead code. */
const settle = <T,>(value: T, ms = 120): Promise<T> =>
  new Promise((resolve) => setTimeout(() => resolve(value), ms))

export const api = {
  teams: (): Promise<Team[]> =>
    isLive ? get<{ teams: Team[] }>('/teams').then((r) => r.teams) : settle(engine.TEAMS),

  team: (key: string | number): Promise<{ team: Team; roster: Player[] }> =>
    isLive
      ? get(`/teams/${key}`)
      : settle({ team: engine.getTeam(key)!, roster: engine.roster(key) }),

  searchPlayers: (q: string, limit = 24): Promise<Player[]> =>
    isLive
      ? get<{ results: Player[] }>(`/players?q=${encodeURIComponent(q)}&limit=${limit}`)
          .then((r) => r.results)
      : settle(engine.searchPlayers(q, limit), 60),

  player: (id: number): Promise<{
    player: Player; team: Team; career: SeasonRow[]; gameLogs: GameLog[]
    radar: Array<{ axis: string; value: number; raw: number }>
    splits: ReturnType<typeof engine.splits>
  }> => {
    if (isLive) return get(`/players/${id}`)
    const player = engine.getPlayer(id)!
    const logs = engine.gameLogs(player)
    return settle({
      player,
      team: engine.getTeam(player.teamId)!,
      career: engine.careerSeasons(player),
      gameLogs: logs,
      radar: engine.radar(player),
      splits: engine.splits(logs),
    })
  },

  headToHead: (playerId: number, opponent: string): Promise<{
    player: Player; opponent: Team; games: H2HGame[]
  }> => {
    if (isLive) return get(`/h2h/${playerId}/${opponent}`)
    const player = engine.getPlayer(playerId)!
    return settle({
      player, opponent: engine.getTeam(opponent)!,
      games: engine.headToHead(player, String(opponent).toUpperCase()),
    })
  },

  predictPlayer: (body: {
    playerId: number; opponent: string | number; isHome: boolean
    restDays: number; isPlayoffs: boolean
  }): Promise<PlayerPrediction> =>
    isLive
      ? post('/predict/player', body)
      : settle(engine.predictPlayer(body.playerId, body.opponent, body), 220),

  predictTeam: (body: {
    home: string | number; away: string | number; isPlayoffs: boolean
    homeRest: number; awayRest: number; series: boolean
  }): Promise<TeamPrediction> =>
    isLive
      ? post('/predict/team', body)
      : settle(engine.predictTeam(body.home, body.away, body), 220),

  fantasyPool: (budget: number): Promise<PricedPlayer[]> =>
    isLive
      ? get<{ players: PricedPlayer[] }>(`/fantasy/pool?budget=${budget}`).then((r) => r.players)
      : settle(engine.pricePool(budget)),

  simulate: (body: {
    budget: number; roster: Array<{ playerId: number; cost: number }>
    opponent: string | number; seed: number; isPlayoffs: boolean
    userIsHome: boolean; monteCarloRuns: number
  }): Promise<SimResult> => {
    if (isLive) return post('/fantasy/simulate', body)
    const picks = body.roster.map((r) => engine.getPlayer(r.playerId)!).filter(Boolean)
    return settle(engine.runSimulation(picks, body.opponent, {
      seed: body.seed, isPlayoffs: body.isPlayoffs,
      userIsHome: body.userIsHome, monteCarloRuns: body.monteCarloRuns,
    }), 0)
  },
}
