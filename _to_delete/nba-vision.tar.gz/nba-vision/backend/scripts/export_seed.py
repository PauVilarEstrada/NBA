"""Dump the demo dataset to JSON for the frontend's offline mode.

    python scripts/export_seed.py ../frontend/src/lib/seed.generated.json

Keeps a single source of truth for the demo league: the frontend never
hand-maintains a parallel roster.
"""
from __future__ import annotations

import json
import sys

sys.path.insert(0, ".")

from app.services import catalog  # noqa: E402
from app.services.seed import CURRENT_SEASON, DEF_VS_POSITION  # noqa: E402

out = {
    "season": CURRENT_SEASON,
    "generatedBy": "backend/scripts/export_seed.py",
    "teams": catalog.all_teams(),
    "players": [
        {k: p[k] for k in ("playerId", "name", "firstName", "lastName", "slug",
                           "team", "teamId", "position", "age", "min", "pts", "reb",
                           "ast", "stl", "blk", "tov", "fg3m", "ts", "usg", "salary",
                           "estimatedValue", "marketPrice", "valueIndex", "surplus",
                           "leagueMax", "headshot", "teamLogo")}
        for p in catalog.all_players()
    ],
    "defVsPosition": DEF_VS_POSITION,
}

path = sys.argv[1] if len(sys.argv) > 1 else "seed.json"
with open(path, "w", encoding="utf-8") as fh:
    json.dump(out, fh, indent=1)
print(f"wrote {path}: {len(out['players'])} players, {len(out['teams'])} teams")
