"""In-memory catalogue built from the seed (demo mode) or from Postgres (live).

Services always call the catalogue, never the seed directly, so switching to the
database is one branch here and no change anywhere else.
"""
from __future__ import annotations

from functools import lru_cache

from app.providers.assets import headshot, team_logo
from app.services import market_value as mv
from app.services.reference import TEAM_BY_ABBR, team_dict
from app.services.seed import (CURRENT_SEASON, DEF_VS_POSITION, PLAYERS, TEAM_RATINGS)

_FIELDS = ("playerId", "firstName", "lastName", "team", "position", "age", "min",
           "pts", "reb", "ast", "stl", "blk", "tov", "fg3m", "ts", "usg", "salary")


def _slug(first: str, last: str) -> str:
    import re
    return re.sub(r"[^a-z0-9]+", "-", f"{first} {last}".lower()).strip("-")


@lru_cache(maxsize=1)
def all_players() -> list[dict]:
    out = []
    league_max = 0
    for row in PLAYERS:
        p = dict(zip(_FIELDS, row))
        p["name"] = f'{p["firstName"]} {p["lastName"]}'
        p["slug"] = _slug(p["firstName"], p["lastName"])
        p["teamId"] = TEAM_BY_ABBR[p["team"]][0]
        p["headshot"] = headshot(p["playerId"])
        p["teamLogo"] = team_logo(p["teamId"])
        est = mv.estimate_value(p, p["age"], 68, CURRENT_SEASON)
        p["estimatedValue"] = est
        p["marketPrice"] = mv.blended_price(p["salary"], est)
        league_max = max(league_max, p["marketPrice"])
        out.append(p)
    for p in out:
        p["valueIndex"] = round(100 * p["marketPrice"] / league_max, 1)
        p["surplus"] = p["estimatedValue"] - p["salary"]
        p["leagueMax"] = league_max
    return out


@lru_cache(maxsize=1)
def players_by_id() -> dict[int, dict]:
    return {p["playerId"]: p for p in all_players()}


def get_player(player_id: int) -> dict | None:
    return players_by_id().get(int(player_id))


def search_players(q: str, limit: int = 20) -> list[dict]:
    q = (q or "").strip().lower()
    pool = all_players()
    if not q:
        return sorted(pool, key=lambda p: -p["pts"])[:limit]
    scored = []
    for p in pool:
        name = p["name"].lower()
        if name.startswith(q):
            score = 0
        elif q in name:
            score = 1
        elif q in p["team"].lower():
            score = 2
        else:
            continue
        scored.append((score, -p["pts"], p))
    scored.sort(key=lambda t: (t[0], t[1]))
    return [p for _, _, p in scored[:limit]]


@lru_cache(maxsize=1)
def all_teams() -> list[dict]:
    out = []
    for abbr, (off, deff, pace, w, l) in TEAM_RATINGS.items():
        t = team_dict(TEAM_BY_ABBR[abbr][0])
        t.update({
            "offRating": off, "defRating": deff, "netRating": round(off - deff, 1),
            "pace": pace, "wins": w, "losses": l,
            "winPct": round(w / (w + l), 3),
            "defVsPosition": DEF_VS_POSITION[abbr],
        })
        out.append(t)
    out.sort(key=lambda t: -t["netRating"])
    for i, t in enumerate(out, 1):
        t["netRatingRank"] = i
    return out


@lru_cache(maxsize=1)
def teams_by_id() -> dict[int, dict]:
    return {t["teamId"]: t for t in all_teams()}


@lru_cache(maxsize=1)
def teams_by_abbr() -> dict[str, dict]:
    return {t["abbr"]: t for t in all_teams()}


def get_team(key: int | str) -> dict | None:
    if isinstance(key, str) and not key.isdigit():
        return teams_by_abbr().get(key.upper())
    return teams_by_id().get(int(key))


def roster(team_key: int | str) -> list[dict]:
    t = get_team(team_key)
    if not t:
        return []
    return sorted([p for p in all_players() if p["teamId"] == t["teamId"]],
                  key=lambda p: -p["pts"])


def cap_sheet(team_key: int | str) -> dict:
    from app.providers.contracts import cap_for

    t = get_team(team_key)
    r = roster(team_key)
    cap = cap_for(CURRENT_SEASON)
    committed = sum(p["salary"] for p in r)
    return {
        "teamId": t["teamId"], "abbr": t["abbr"], "salaryCap": cap,
        "committed": committed, "capSpace": cap - committed,
        "overCap": committed > cap,
        "luxuryTax": int(cap * 1.2158),
        "taxBill": max(0, committed - int(cap * 1.2158)),
        "players": [{"playerId": p["playerId"], "name": p["name"],
                     "salary": p["salary"], "estimatedValue": p["estimatedValue"],
                     "surplus": p["surplus"]} for p in r],
    }
