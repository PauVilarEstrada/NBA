# NBA Vision

A full-stack NBA analytics, projection and simulation lab. Search and compare
players and teams, look up head-to-head history split by venue, project a
player's line against a specific defence, forecast a full game (regular season
*or* playoffs, on separate models), and build a roster under a budget to play
against a real NBA team with a possession-level simulator and a live timelapse
replay.

**It runs with zero setup.** `cd frontend && npm install && npm run dev` gives
you the whole site against a built-in demo league and a calibrated baseline
model. Add the backend for live stats.nba.com data, PostgreSQL caching and
trained models — the API contract is identical, so nothing in the UI changes.

---

## Quick start

### Frontend only (demo mode — no Python, no database)

```bash
cd frontend
npm install
npm run dev            # http://localhost:5173
```

### Full stack

```bash
cp .env.example .env
docker compose up -d db redis
cd backend
pip install -r requirements.txt
psql "$NBA_DATABASE_URL" -f sql/schema.sql
uvicorn app.main:app --reload        # http://localhost:8000/docs

# point the frontend at it
cd ../frontend
echo 'VITE_API_URL=http://localhost:8000/api' > .env.local
npm run dev
```

Or the whole thing at once:

```bash
docker compose up --build
```

### Load real data and train

```bash
cd backend
python scripts/ingest.py teams
python scripts/ingest.py players  --season 2025-26
python scripts/ingest.py games    --seasons 2015..2025    # slow: rate-limited on purpose
python scripts/ingest.py contracts --season 2025
python scripts/ingest.py features --seasons 2015..2025
python -m app.ml.train --what all --season-type both
curl -XPOST localhost:8000/api/admin/reload-models
```

---

## What is where

```
nba-vision/
├─ backend/
│  ├─ app/
│  │  ├─ main.py                 FastAPI app, CORS, gzip, timing, model boot
│  │  ├─ core/                   settings, two-tier cache, errors
│  │  ├─ db/                     SQLAlchemy session + mapped models
│  │  ├─ sql/schema.sql          the source of truth for the database
│  │  ├─ providers/              stats.nba.com, Basketball-Reference, Spotrac,
│  │  │                          HoopsHype, RealGM, cdn.nba.com assets
│  │  ├─ services/               catalogue, market value, synthetic history,
│  │  │                          predictions, fantasy builder
│  │  ├─ ml/                     features, distributions, player model,
│  │  │                          team model, sequence model, simulator,
│  │  │                          registry, calibrated mock, training CLI
│  │  └─ api/routes/             players, teams, h2h, predict, fantasy, meta
│  └─ scripts/                   ingest.py, export_seed.py
├─ frontend/
│  └─ src/
│     ├─ lib/                    api adapter, offline engine, stats, palette
│     ├─ components/ui|charts|player|sim
│     ├─ pages/                  the seven sections
│     └─ store/                  theme, fantasy builder
└─ docs/                         architecture, data sources, ML pipeline,
                                 how the AI is mocked, design system
```

## The seven sections

| Route | What it does |
|---|---|
| `/players`, `/players/:id` | Index and full profile: bio, season-by-season, skill radar, market value, situational splits, game log |
| `/compare` | Two to four players on shared axes: radar overlay, grouped bars, a table with the leader marked |
| `/teams`, `/teams/:abbr` | Ratings, pace, roster, cap sheet with the luxury-tax line, and a team-vs-team comparison |
| `/head-to-head` | Every meeting between a player and one opponent, home and away plotted separately |
| `/predict/player` | Points / rebounds / assists / threes vs a chosen defence, with an 80% interval, an over/under, and a breakdown of what moved the number |
| `/predict/team` | Score, spread, total, win probability; playoffs switch to a different model and add an exact best-of-seven probability |
| `/builder` | Budget, priced player pool, roster building, opponent selection, and a possession-level simulation replayed at 1 real second per game minute |

## Design and honesty rules this project follows

- **No projection ships without its uncertainty.** Every forecast carries an
  interval and an over/under built from predicted quantiles, not a point estimate.
- **Every mocked number is labelled.** When no trained artefact is loaded the
  response is tagged `"source": "mock"` and the UI renders a visible badge.
- **Colour never carries meaning alone.** Every chart has a legend, direct
  labels and a table view; the categorical palette was validated for
  colour-vision deficiency against both the dark and the light surface.
- **No dual-axis charts.** Two measures on different scales get two charts.
- **Deterministic output.** Projections and simulations are seeded, so the same
  question always gives the same answer.

Read `docs/` for the details.

## Licence and attribution

Portfolio project. Not affiliated with or endorsed by the NBA. Player and team
imagery is served from the official `cdn.nba.com` endpoints and remains © NBA.
Respect each data source's terms before pointing the ingest jobs at production.
